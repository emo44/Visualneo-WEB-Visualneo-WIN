
<?php
// Allow from any origin
//header('Access-Control-Allow-Origin: *');
//header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

if(isset($_FILES['file']['name'])){
	// file name
	$filename = $_FILES['file']['name'];
	//if you want files not to overwrite comment line above and descoment line below. it add a 5 digits random number at the begining of the file.
	//$filename = random_int(10000,99000)."_".$_FILES['file']['name'];;
	
	// Location
	$location = 'upload/'.$filename;

	// file extension
	$file_extension = pathinfo($location, PATHINFO_EXTENSION);
	$file_extension = strtolower($file_extension);

	// Valid image extensions
	$valid_ext = array("pdf","doc","docx","jpg","png","jpeg");

	$response = 0;
	if(in_array($file_extension,$valid_ext)){
	  	// Upload file
	  	if(move_uploaded_file($_FILES['file']['tmp_name'],$location)){
	    	$response = 1;
	  	}	
	}

	echo $response;
	exit;
}



